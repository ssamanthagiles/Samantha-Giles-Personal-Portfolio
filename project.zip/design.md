Oringinally took my code for the problem set homepaged and added alot more:

Original program entailed.

Four Different HTML files:
1. index.html
2. about_me.html
3. lifestyle.html
4. my_work.html

HTML tags:
1. <img
2. <nav
3. <div
4. <button
5. <span
6. <ul
7. <a
8. <li
9. <form
10. <p
11. <script>

Bootstrap: Used for the navigation bar!

CSS properties:
1.
.nav-container {
    width: 50%; /* or whatever width you want */
    margin: 0 auto;
  }

2.
.p1 {
    font-family: "Times New Roman", Times, serif;
  }

3.
p {
    font-size: 20px;
  }

4.
  p.double {
    border-style: double;
  }

5.
  p {
    margin: 10px;
  }

Javascript:
1. The alert


I knew I wanted pages for a blog document, which is how I decided to add a blog portion to my navigation bar. So I changed my navigation bar to be just short words (i.e instead of my work, just work) to create easier usability. Additonally, I got rid of the search bar because after talking to my friends, they thought it was unneccessary to have a search bar in a personal portfolio.

I prefer times new roman, so if you see any font on my personal portfolio it's in times new roman just out of preference. I also really liked the border I choose when doing the homepage problem set, so I stuck on theme with that. Since this is a professional portfolio (for example, me including a work section and my linkedin on the portfolio), I wanted everything to be cohesive which is why I included that for continuity.

I wanted this to be a good showcase of who I am as a perosn, which is why I added so many pictures of me/pictures I've taken. I had to upload and crop different pictures and then I Adjusted the height and width of the pictures.

I wanted to continue a javascript element, but if you remeber from my original homepage, my javascript alert didn't fit the theme of my personal portfolio, so I changed it, welcoming users to my personal portfolio.

While thinking of other design elements, you can see that most times I implement a photo into my website on the right side to stick with the cohesive theme with the text being on the left side. I also used a black and white theme agian to maintain proffesionalism. So the icons that I used being black and white were for me to stick with the same theme and also text was in black and the background was white to again stick to the theme. 