User manual

The first step, is to change directory into homepage by typign in cd homepage into terminal. Once into the directory homepage, need to type http-server into the terminal and copy and paste the link that should look like this:  https://curly-eureka-69g7rxgxx757cr44q-8080.app.github.dev into browser.

What I created is a perosnal portfolio that showcases who I am as an individaul. I have blog posts, an about me section, a work section, and a lifestyle section. When you first copy the website into your browser and hit go, an alert will pop up essentially welcoming you to my personal portfolio. You can click out of that and procced onto my personal portfolio!

You can hover your mouse over and click on each tab on the navigation bar to access different aspects of the website. Also the icons of Instagram, LinkedIn, and Tiktok will direct users to my social media platforms. If you wish to go back to my perosnal portfolio, simply hit the back arrow key and go back.

For the blog specifically, you can scroll and click on each blog topic. When you click on the blog topic, you will see the option to go through and look through more blog sections that pertain to that section if you so choose. You can go back to the blog page by clicking the blog page (at the top navigation bar).

I used the resources CS50.ai duck and attended office hours for help! As stated on the CS50 website, "For your final project (and your final project only!) it is reasonable to use AI-based software other than CS50’s own (e.g., ChatGPT, GitHub Copilot, Bing Chat, et al.), but the essence of the work must still be your own. You’ve learned enough to use such tools as helpers. Treat such tools as amplifying, not supplanting, your productivity." I did use chatgpt to help with my personal protfolio becasue it said that it was reasonable.

Here is the link to my video (which is unlisted on youtube:) - https://youtu.be/Euz8LxYEZ8Q

ALso, the video does show my concentration (i.e when I scroll down on my work history portion of my personal portfolio)

This class has definetly taught me so much and I'm so grateful for everything that I've learned while taking this class.